# Azure "Directory (tenant) ID" from the app registration
GRAPH_TENANT_ID <- "7bedec4d-862e-45c9-8db5-ef5c5f8970b9"

# Azure "Application (client) ID" from the app registration
GRAPH_CLIENT_ID <- "5975c521-081e-48e3-9d03-da92710c5318"

# The secret value you copied when you created it
GRAPH_CLIENT_SECRET <- "eOp8Q~EUCA5ZLdN9tkyKJJ3DdY09DvrefFem6c5l"

# error@myfirepulse.com
ERROR_EMAIL <- 'richeyjojo@gmail.com'



NotifyError <- function(message, context = "", currentUser = NULL) {

  # Resolve reactive if needed (same pattern as AuditLog)
  user <- tryCatch(
    if (shiny::is.reactive(currentUser)) currentUser() else currentUser,
    error = function(e) NULL
  )
  user_label <- if (!is.null(user) && nzchar(user)) user else "Unknown"

  # Always log first — this must never fail silently
  logger::log_error(
    glue::glue("{message} | User: {user_label}"),
    namespace = if (nzchar(context)) context else "NotifyError"
  )

  # Attempt email — swallow all failures so the notifier never causes more errors
  tryCatch({

    # --- 1. Read credentials from environment ---
    tenant_id     <- GRAPH_TENANT_ID
    client_id     <- GRAPH_CLIENT_ID
    client_secret <- GRAPH_CLIENT_SECRET
    error_email   <- ERROR_EMAIL

    # Bail early if any credential is missing rather than sending a bad request
    missing_vars <- c(
      if (!nzchar(tenant_id))     "GRAPH_TENANT_ID",
      if (!nzchar(client_id))     "GRAPH_CLIENT_ID",
      if (!nzchar(client_secret)) "GRAPH_CLIENT_SECRET",
      if (!nzchar(error_email))   "ERROR_EMAIL"
    )
    if (length(missing_vars) > 0) {
      logger::log_warn(
        glue::glue("NotifyError: skipping email — missing env vars: {paste(missing_vars, collapse = ', ')}"),
        namespace = "NotifyError"
      )
      return(invisible(NULL))
    }

    # --- 2. Acquire access token ---
    token_response <- httr2::request("https://login.microsoftonline.com") |>
      httr2::req_url_path_append(tenant_id) |>
      httr2::req_url_path_append("oauth2/v2.0/token") |>
      httr2::req_body_form(
        grant_type    = "client_credentials",
        client_id     = client_id,
        client_secret = client_secret,
        scope         = "https://graph.microsoft.com/.default"
      ) |>
      httr2::req_perform() |>
      httr2::resp_body_json()

    access_token <- token_response$access_token

    # --- 3. Compose HTML email body via blastula ---
    timestamp <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")

    email_body <- blastula::compose_email(
      body = blastula::md(glue::glue(
        "## Application Error\n\n",
        "This is a test email."
      )),
      footer = blastula::md("Sent automatically by FirePulse.")
    )

    # --- 4. Send via Graph API ---
    subject <- glue::glue(
      "[FirePulse Error]"
    )

    httr2::request("https://graph.microsoft.com/v1.0") |>
      httr2::req_url_path_append("users/reports@myfirepulse.com/sendMail") |>
      httr2::req_auth_bearer_token(access_token) |>
      httr2::req_body_json(list(
        message = list(
          subject = subject,
          body = list(
            contentType = "HTML",
            content     = email_body$html_str
          ),
          toRecipients = list(
            list(emailAddress = list(address = error_email))
          )
        )
      )) |>
      httr2::req_perform()

    logger::log_info(
      glue::glue("Error notification email sent to {error_email}"),
      namespace = "NotifyError"
    )

  }, error = function(email_err) {
    # Log but never re-throw — a broken email config must not mask the original error
    logger::log_warn(
      glue::glue("NotifyError: failed to send email — {email_err$message}"),
      namespace = "NotifyError"
    )
  })

  invisible(NULL)
}
